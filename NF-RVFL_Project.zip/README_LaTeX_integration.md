The LaTeX supplementary file is located at `supplementary/supplementary.tex`. It documents defuzzification used in the code.
