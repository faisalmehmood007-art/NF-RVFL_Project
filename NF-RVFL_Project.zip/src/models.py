"""Simple implementations of RVFL and NF-RVFL variants.

NF-RVFL implements:
- clustering per-feature (R-means, K-means, Fuzzy C-means)
- feature-aware fuzzy integration
- randomized hidden layer and closed-form output weights (pseudoinverse)
"""
import numpy as np
from sklearn.cluster import KMeans
from numpy.linalg import pinv
import math

def _sigmoid(x): return 1.0/(1.0+np.exp(-x))
def _tanh(x): return np.tanh(x)
def _relu(x): return np.maximum(0,x)

class RVFL:
    def __init__(self, n_hidden=100, activation='tanh', random_state=None):
        self.n_hidden = n_hidden
        self.activation = activation
        self.random_state = random_state
        self._rng = np.random.RandomState(random_state)

    def _act(self, X):
        if self.activation == 'tanh': return _tanh(X)
        if self.activation == 'sigmoid': return _sigmoid(X)
        if self.activation == 'relu': return _relu(X)
        return X

    def fit(self, X, y, reg=1e-4):
        M, d = X.shape
        self.W = self._rng.normal(scale=1.0, size=(d, self.n_hidden))
        self.b = self._rng.normal(scale=0.1, size=(self.n_hidden,))
        H = self._act(X.dot(self.W) + self.b)
        D = np.hstack([X, H])
        # closed-form ridge: (D^T D + reg I)^-1 D^T y, but we'll use pseudoinverse with tiny reg
        self.beta = pinv(D.T.dot(D) + reg*np.eye(D.shape[1])).dot(D.T).dot(y)
        self.D = D

    def predict(self, X):
        H = self._act(X.dot(self.W) + self.b)
        D = np.hstack([X, H])
        y = D.dot(self.beta)
        # if classification, return class labels by rounding for binary/multiclass
        if y.ndim == 1:
            # try to detect classification by small integer labels in training beta
            return (y > 0.5).astype(int) if np.all(np.logical_or(self.D.dot(self.beta) == 0, self.D.dot(self.beta) == 1)) else y
        return y

class NF_RVFL(RVFL):
    def __init__(self, n_hidden=100, n_clusters=3, clustering='K', activation='tanh', random_state=None):
        super().__init__(n_hidden=n_hidden, activation=activation, random_state=random_state)
        self.n_clusters = n_clusters
        self.clustering = clustering  # 'R' (random), 'K' (kmeans), 'C' (fcm)
        self.feature_weights = None
        self.cluster_centers_ = None
        self.spreads_ = None

    def _gauss_membership(self, x, centers, spreads):
        # x: (n_samples,), centers: (K,), spreads: (K,)
        # return (n_samples, K)
        x = x.reshape(-1,1)
        return np.exp(-0.5 * ((x - centers.reshape(1,-1))**2) / (spreads.reshape(1,-1)**2 + 1e-12))

    def _fuzzy_c_means_1d(self, x, K, m=2.0, max_iter=100, tol=1e-5):
        # simple 1D FCM for a single feature vector x
        n = x.shape[0]
        # init centers via kmeans
        km = KMeans(n_clusters=K, random_state=self.random_state).fit(x.reshape(-1,1))
        centers = km.cluster_centers_.ravel()
        U = np.zeros((n, K))
        for iteration in range(max_iter):
            # update membership U
            for j in range(K):
                denom = np.sum(((x.reshape(-1,1) - centers.reshape(1,-1)) / (x.reshape(-1,1) - centers[j] + 1e-8))**(2/(m-1)), axis=1)
                # avoid divide by zero
                U[:,j] = 1.0 / (np.sum(((x.reshape(-1,1)-centers[j])/(x.reshape(-1,1)-centers+1e-8))**(2/(m-1)), axis=1) + 1e-12)
            U = np.nan_to_num(U)
            Um = U**m
            centers_new = (Um.T.dot(x)) / (Um.sum(axis=0) + 1e-12)
            if np.linalg.norm(centers_new - centers) < tol:
                centers = centers_new
                break
            centers = centers_new
        # spreads: use std of points weighted by membership
        spreads = np.zeros(K)
        for j in range(K):
            w = U[:,j]
            mu = np.sum(w * x) / (np.sum(w) + 1e-12)
            spreads[j] = np.sqrt(np.sum(w * (x - mu)**2) / (np.sum(w) + 1e-12)) + 1e-6
            if spreads[j] <= 0: spreads[j] = 1e-2
        return centers, spreads, U

    def fit(self, X, y, reg=1e-4):
        # Per-feature clustering to obtain centers and spreads
        M, d = X.shape
        self.cluster_centers_ = []
        self.spreads_ = []
        self.feature_weights = np.ones(d)
        for i in range(d):
            xi = X[:,i]
            if self.clustering == 'R':
                # random centers sampled from data's range
                mins, maxs = xi.min(), xi.max()
                centers = np.linspace(mins, maxs, self.n_clusters)
                spreads = np.full(self.n_clusters, max(1e-3, (maxs-mins)/self.n_clusters))
            elif self.clustering == 'K':
                km = KMeans(n_clusters=self.n_clusters, random_state=self.random_state).fit(xi.reshape(-1,1))
                centers = np.sort(km.cluster_centers_.ravel())
                # spreads: distance to nearest neighbor cluster center or std within cluster
                spreads = np.ones(self.n_clusters) * (xi.std() + 1e-6)
            elif self.clustering == 'C':
                centers, spreads, _U = self._fuzzy_c_means_1d(xi, self.n_clusters)
                centers = np.sort(centers)
            else:
                raise ValueError('Unknown clustering')
            self.cluster_centers_.append(centers)
            self.spreads_.append(spreads)
        # compute feature-aware fuzzy transform for each sample and feature
        X_fuzzy = []
        for i in range(d):
            centers = np.array(self.cluster_centers_[i])
            spreads = np.array(self.spreads_[i])
            mu = self._gauss_membership(X[:,i], centers, spreads)  # M x K
            # defuzzified numeric summary per feature: weighted average of centers by membership
            defuzz = (mu * centers.reshape(1,-1)).sum(axis=1) / (mu.sum(axis=1) + 1e-12)
            xi_tilde = self.feature_weights[i] * X[:,i] + (1 - self.feature_weights[i]) * defuzz
            X_fuzzy.append(xi_tilde.reshape(-1,1))
        X_fuzzy = np.hstack(X_fuzzy)
        # combine original X and fuzzy X_fuzzy and continue as RVFL
        X_comb = np.hstack([X, X_fuzzy])
        # hidden layer on fuzzy-enhanced features
        self.W = self._rng.normal(scale=1.0, size=(X_comb.shape[1], self.n_hidden))
        self.b = self._rng.normal(scale=0.1, size=(self.n_hidden,))
        H = self._act(X_comb.dot(self.W) + self.b)
        D = np.hstack([X, X_fuzzy, H])
        self.beta = pinv(D.T.dot(D) + reg*np.eye(D.shape[1])).dot(D.T).dot(y)
        # store for later prediction checks
        self.D = D
        self.X_fuzzy_template = (self.cluster_centers_, self.spreads_, self.feature_weights)

    def predict(self, X):
        # compute fuzzy transform using stored centers/spreads/weights
        centers_all, spreads_all, wts = self.X_fuzzy_template
        M, d = X.shape
        X_fuzzy = []
        for i in range(d):
            centers = np.array(centers_all[i])
            spreads = np.array(spreads_all[i])
            mu = self._gauss_membership(X[:,i], centers, spreads)
            defuzz = (mu * centers.reshape(1,-1)).sum(axis=1) / (mu.sum(axis=1) + 1e-12)
            xi_tilde = wts[i] * X[:,i] + (1 - wts[i]) * defuzz
            X_fuzzy.append(xi_tilde.reshape(-1,1))
        X_fuzzy = np.hstack(X_fuzzy)
        X_comb = np.hstack([X, X_fuzzy])
        H = self._act(X_comb.dot(self.W) + self.b)
        D = np.hstack([X, X_fuzzy, H])
        y = D.dot(self.beta)
        # Heuristic: if training outputs were integers, return rounded labels
        if np.allclose(self.D.dot(self.beta), np.round(self.D.dot(self.beta))):
            return np.round(y).astype(int)
        return y
