# NF-RVFL: Feature-Aware Neuro-Fuzzy Random Vector Functional Link

This repository contains a runnable implementation of the NF-RVFL project (Python).

**Contents**
- `src/` : Python source files (models, utils)
- `data/` : Example datasets (loaded from scikit-learn at runtime)
- `notebooks/` : Example usage notebook
- `main.py` : Example script to train & evaluate models on sample datasets
- `requirements.txt` : Python dependencies
- `supplementary/` : LaTeX supplementary material

**Run example**
```bash
python main.py --dataset breast_cancer --model nf-rvfl-c
```
