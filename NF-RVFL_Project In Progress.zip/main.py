"""Example runner for NF-RVFL models.

Usage:
    python main.py --dataset breast_cancer --model nf-rvfl-c
"""
import argparse
import numpy as np
import pandas as pd
from sklearn import datasets
from sklearn.model_selection import cross_val_score, StratifiedKFold, KFold
from sklearn.preprocessing import StandardScaler
from src.models import RVFL, NF_RVFL
from sklearn.metrics import accuracy_score, mean_squared_error

def load_dataset(name):
    if name == 'breast_cancer':
        data = datasets.load_breast_cancer()
        X, y = data.data, data.target
        task = 'classification'
    elif name == 'wine':
        data = datasets.load_wine()
        X, y = data.data, data.target
        task = 'classification'
    elif name == 'boston':
        data = datasets.load_boston()
        X, y = data.data, data.target
        task = 'regression'
    else:
        raise ValueError('Unknown dataset')
    return X, y, task

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', default='breast_cancer', choices=['breast_cancer','wine','boston'])
    parser.add_argument('--model', default='nf-rvfl-c', choices=['rvfl','nf-rvfl-r','nf-rvfl-k','nf-rvfl-c'])
    args = parser.parse_args()

    X, y, task = load_dataset(args.dataset)
    scaler = StandardScaler()
    X = scaler.fit_transform(X)

    if args.model == 'rvfl':
        model = RVFL(n_hidden=100, activation='tanh', random_state=42)
    else:
        variant = args.model.split('-')[-1]  # r, k, c
        model = NF_RVFL(n_hidden=100, n_clusters=3, clustering=variant.upper(), activation='tanh', random_state=42)

    if task == 'classification':
        cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
        scores = []
        for train_idx, test_idx in cv.split(X,y):
            model.fit(X[train_idx], y[train_idx])
            y_pred = model.predict(X[test_idx])
            scores.append(accuracy_score(y[test_idx], y_pred))
        print(f"Model: {args.model} on {args.dataset}: Accuracy = {np.mean(scores):.4f} +/- {np.std(scores):.4f}")
    else:
        cv = KFold(n_splits=5, shuffle=True, random_state=42)
        scores = []
        for train_idx, test_idx in cv.split(X):
            model.fit(X[train_idx], y[train_idx])
            y_pred = model.predict(X[test_idx])
            scores.append(mean_squared_error(y[test_idx], y_pred))
        print(f"Model: {args.model} on {args.dataset}: RMSE = {np.sqrt(np.mean(scores)):.4f}")

if __name__ == '__main__':
    main()
